/// <reference types="react-scripts" />

declare module '*.png' {
  const value: any;
  export default value;
}
